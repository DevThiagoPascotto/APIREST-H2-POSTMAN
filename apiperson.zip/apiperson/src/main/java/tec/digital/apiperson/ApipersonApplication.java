package tec.digital.apiperson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApipersonApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApipersonApplication.class, args);
	}

}
